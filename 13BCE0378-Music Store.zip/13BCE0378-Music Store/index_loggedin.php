<?php
	ob_start();
    session_start();
?>
<?php
	include 'header_c.php';
	include 'connect.php';
	$current_file=$_SERVER['SCRIPT_NAME'];
	if(isset($_SERVER['HTTP_REFERER'])&&!empty($_SERVER['HTTP_REFERER']))
	{$http_referer=$_SERVER['HTTP_REFERER'];}
	if(isset($_SESSION["user_id"])&& !empty($_SESSION["user_id"]))
	{
		$k=$_SESSION['user_id'];
		$qry="SELECT `username` FROM `user` where `uid`=$k";
		if($query_run=mysql_query($qry))
		{
			$name=mysql_result($query_run,0,'username');
			echo '<span style="text-align:left;text-transform:capitalize;font-family:Comic Sans MS;color:#fdfdfd;position:fixed;top:90px;z-index:2;">Welcome '.$name;
			echo "</span>";
			echo '<a href="upload.php" style="text-transform:capitalize;font-family:Comic Sans MS;color:#fdfdfd;position:fixed;top:90px;right:100px;z-index:2;">Upload';
			echo '</a>';
			echo '<a href="logout.php" style="text-transform:capitalize;font-family:Comic Sans MS;color:#fdfdfd;position:fixed;top:90px;right:7px;z-index:2;">Logout';
			echo '</a>';
		}	
	}	
	echo '<h2 style="text-align:center;text-transform:capitalize;font-family:Comic Sans MS;">Your Albums</h2>';
	$qry="SELECT `aid`,`apath`,`aname` FROM album_t WHERE `uid`='".$_SESSION['user_id']."'";
	$result=mysql_query($qry);
	while($row=mysql_fetch_assoc($result))
	{
		$img=$row["apath"];
		if(empty($img))
		{
			$img="Album/download.png";
		}	
		echo "<html><head>";
		echo '<link rel="stylesheet" type="text/css" href="css/album_info.css">';
		echo "<head>";
		echo '<div class="album_info">';
		echo	'<img src="'.$img.'" width="128" height="140"><br />';
		echo	'<a href="index_loggedin.php?aid='.$row["aid"].'" class="imgdesc">'.$row["aname"].'</a>';
		echo '</div>';
	}	
	if(mysql_num_rows($result)==0)
	{
		echo '<img src="Album/profile.png" width="100px" style="position:relative;left:630px;"/>';
		echo '<h3 style="text-align:center;font-family:Comic Sans MS;">Well to listen something of your type,please enter some data.';
		echo "</h3>";
	}	
	 if (isset($_GET['aid'])) {
			album_click($_GET['aid']);
	}
	function album_click($k)
	{
			$qry="SELECT `aid` FROM `album_t`";
			$result=mysql_query($qry);
			if(mysql_result($result,0,'aid')===$k);
			{  
				$album_id=$k;
				$_SESSION["album_id"]=$album_id;
				header('Location:song_list.php');
				echo $_SESSION["album_id"];
			}
			//else
				//echo "Can't find the required album id";
	}
		
?>

