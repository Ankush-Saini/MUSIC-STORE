-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 04, 2016 at 09:50 AM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ms_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `album_t`
--

CREATE TABLE IF NOT EXISTS `album_t` (
  `aid` int(5) NOT NULL,
  `apath` varchar(50) NOT NULL,
  `aname` varchar(40) NOT NULL,
  `lid` int(3) NOT NULL,
  `uid` int(3) NOT NULL,
  `releasetype` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `album_t`
--

INSERT INTO `album_t` (`aid`, `apath`, `aname`, `lid`, `uid`, `releasetype`) VALUES
(1, 'Album/fastnfurios.jpg', 'Fast and Furios 7', 2, 1, ''),
(2, 'Album/M5V.jpg', 'Maroon 5', 2, 1, 'new'),
(3, 'Album/rockstar.jpg', 'Rockstar', 1, 1, ''),
(4, 'Album/jtyjn.jpg', 'Jaane Tu...Ya Jaane ', 1, 1, ''),
(7, 'Album/jtyjn.jpg', 'Jaane Tu Ya Jaane Na', 1, 2, ''),
(8, 'Album/bah.jpg', 'Bachna Ae Haseeno', 1, 1, ''),
(9, 'Album/bah.jpg', 'Bachna Ae Haseeno', 1, 2, ''),
(10, 'Album/taurmittrandi.jpg', 'Taur Mittran Di', 3, 2, ''),
(11, 'Album/taurmittrandi.jpg', 'Taur Mittran Di', 3, 1, ''),
(12, '', 'Jab We Met', 1, 2, ''),
(13, '', 'Kismat Konnection', 1, 2, ''),
(15, 'Album/arjit.jpg', 'Love Songs - Arijit ', 1, 2, 'featured'),
(16, 'Album/mashupremix.jpg', 'Mashup Remix', 1, 2, 'featured'),
(17, 'Album/baaghi-songspk.jpg', 'Baaghi', 1, 6, 'new'),
(18, 'Album/ivhoney.jpg', ' International Village-Yo Yo Honey Singh', 3, 1, 'featured');

-- --------------------------------------------------------

--
-- Table structure for table `lang_t`
--

CREATE TABLE IF NOT EXISTS `lang_t` (
  `lid` int(3) NOT NULL,
  `lang` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lang_t`
--

INSERT INTO `lang_t` (`lid`, `lang`) VALUES
(1, 'hindi'),
(2, 'english'),
(3, 'punjabi');

-- --------------------------------------------------------

--
-- Table structure for table `song_t`
--

CREATE TABLE IF NOT EXISTS `song_t` (
  `sid` int(5) NOT NULL,
  `sname` varchar(50) NOT NULL,
  `spath` varchar(100) NOT NULL,
  `aid` int(5) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `song_t`
--

INSERT INTO `song_t` (`sid`, `sname`, `spath`, `aid`) VALUES
(1, 'Ride Out', 'songs/FNF7/Ride Out - Fast & Furious 7 - [Songspk.CC].mp3', 1),
(2, 'Off - Set', 'songs/FNF7/2 - Off - Set - Fast & Furious 7 - [Songspk.CC].mp3', 1),
(3, 'How Bad you want it ', 'songs/FNF7/3 - How Bad Do You Want It - Fast & Furious 7 - [Songspk.CC].mp3', 1),
(4, 'Get Low', 'songs/FNF7/4 - Get Low - Fast & Furious 7 - [Songspk.CC].mp3', 1),
(5, 'Go Hard or Go Home', 'songs/FNF7/5 - Go Hard Or Go Home Fast & Furious 7.mp3', 1),
(6, 'See you Again', 'songs/FNF7/7 - See You Again - Fast & Furious 7 .mp3', 1),
(7, 'Sugar', 'songs/Maroon 5/Maroon 5 - Sugar.mp3', 2),
(8, 'Animals', 'songs/Maroon 5/Maroon 5 - Animals.mp3', 2),
(9, 'Make Me Wonder ', 'songs/Maroon 5/Makes Me Wonder.MP3', 2),
(11, 'Nothing Lasts Forever', 'songs/Maroon 5/Nothing Lasts Forever.MP3', 2),
(12, 'Saadda Haq ', 'songs/Rockstar/Saadda Haq.mp3', 3),
(13, 'Naadaan Parindey', 'songs/Rockstar/Naadaan Parindey.mp3', 3),
(14, 'Jo Bhi Main', 'songs/rockstar/02. Jo Bhi Main.mp3', 3),
(15, 'Phir Se Ud Chala', 'songs/Rockstar/01. Phir Se Ud Chala.mp3', 3),
(16, 'Kateya Karun', 'songs/Rockstar/03. Kateya Karun.mp3', 3),
(17, 'Assi Munde Haan Punjabi', 'songs/Taur Mittran Di/1. Assi Munde Haan Punjabi.mp3', 10),
(18, 'Dil Tera Ho Gaya', 'songs/Taur Mittran Di/2. Dil Tera Ho Gaya.mp3', 10),
(19, 'Assi Munde Haan Punjabi', 'songs/Taur Mittran Di/1. Assi Munde Haan Punjabi.mp3', 11),
(20, 'Dil Tera Ho Gaya', 'songs/Taur Mittran Di/2. Dil Tera Ho Gaya.mp3', 11),
(21, 'Darshan Di Bukh', 'songs/Taur Mittran Di/3. Darshan Di Bukh.mp3', 10),
(22, 'Nai Rukna', 'songs/Taur Mittran Di/4. Nai Rukna.mp3', 10),
(23, 'Darshan Di Bukh', 'songs/Taur Mittran Di/3. Darshan Di Bukh.mp3', 11),
(24, 'Nai Rukna', 'songs/Taur Mittran Di/4. Nai Rukna.mp3', 11),
(25, 'Taur Mittran Di(Title Track)', 'songs/Taur Mittran Di/5. Taur Mittran Di.mp3', 10),
(26, 'Taur Mittran Di(Title Track)', 'songs/Taur Mittran Di/5. Taur Mittran Di.mp3', 11),
(27, 'Kabhi Kabhi Aditi Zindagi', 'songs/jtyjn/01 kabhu kabhi.mp3', 4),
(28, 'Pappu Can''t Dance', 'songs/jtyjn/02 pappu cant dance.mp3', 4),
(29, 'Kabhi Kabhi Aditi Zindagi', 'songs/jtyjn/01 kabhu kabhi.mp3', 7),
(30, 'Pappu Can''t Dance', 'songs/jtyjn/02 pappu cant dance.mp3', 7),
(31, 'Jaanu Tu Mera Kya Hai', 'songs/jtyjn/03 jaane tu mera kya hai.mp3', 4),
(32, 'Nazrein Milaana Nazrein', 'songs/jtyjn/04 nazrain milana.mp3', 4),
(33, 'Jaanu Tu Mera Kya Hai', 'songs/jtyjn/03 jaane tu mera kya hai.mp3', 7),
(34, 'Nazrein Milaana Nazrein', 'songs/jtyjn/04 nazrain milana.mp3', 7),
(35, 'Khuda Jaane', 'songs/BAH/01 khuda jaane.MP3', 8),
(36, 'Lucky Boy', 'songs/BAH/02 lucky boy.MP3', 8),
(37, 'Khuda Jaane', 'songs/BAH/01 khuda jaane.MP3', 9),
(38, 'Lucky Boy', 'songs/BAH/02 lucky boy.MP3', 9),
(39, 'Jogi Mahi', 'songs/BAH/04 jogi mahi.MP3', 9),
(40, 'Small Town Girl', 'songs/BAH/05 smaal town girl.MP3', 9),
(41, 'Jogi Mahi', 'songs/BAH/04 jogi mahi.MP3', 8),
(42, 'Small Town Girl', 'songs/BAH/05 smaal town girl.MP3', 8),
(43, 'Bachna Ae Haseeno(Title Track)', 'songs/BAH/07 bachna ae haseeno.MP3', 8),
(44, 'Bachna Ae Haseeno(Title Track)', 'songs/BAH/07 bachna ae haseeno.MP3', 9),
(50, 'Mauja Hi Mauja', 'songs/JAB WE MET/01. Mauja Hi Mauja.mp3', 12),
(51, 'Tum Se Hi', 'songs/JAB WE MET/02. Tum Se Hi.mp3', 12),
(52, 'Aai Paapi (Tu Hai Meri Soniye)', 'songs/Kismat Konnection/01Aai Paapi (Tu Hai Meri Soniye).mp3', 13),
(55, 'Sab Tera', 'songs/baaghi/01 - Sab Tera [Songspk.LINK].mp3', 17),
(56, 'Let''s Talk About Love', 'songs/baaghi/02 - Let''s Talk About Love [Songspk.LINK].mp3', 17),
(57, 'Cham Cham', 'songs/baaghi/03 - Cham Cham [Songspk.LINK].mp3', 17),
(58, 'Agar Tu Hota', 'songs/baaghi/04 - Agar Tu Hota [Songspk.LINK].mp3', 17),
(59, 'Ek Tha Villian - Mashup', 'songs/mashups/02 - Ek Villain.mp3', 16),
(60, 'Aashiqui 2 -Mashup', 'songs/mashups/04 - Aashiqui 2.mp3', 16),
(61, 'Cocktail - Mashup', 'songs/mashups/18 - Cocktail.mp3', 16),
(62, 'Brown Rang', 'songs/inhoney/01 Brown Rang (DjPunjab.Com).mp3', 18),
(63, 'Angrezi Beat', 'songs/inhoney/02 Angreji Beat Ft. Gippy Grewal (DjPunjab.Com).mp3', 18),
(64, 'Goliyan', 'songs/inhoney/03 Goliyan Ft. Diljit Dosanjh (DjPunjab.Com).mp3', 18),
(65, 'Dope Shope', 'songs/inhoney/04 Dope Shope Ft. Deep Money (DjPunjab.Com).mp3', 18),
(66, 'Gabru', 'songs/inhoney/05 Gabru Ft. J Star (DjPunjab.Com).mp3', 18),
(67, 'Get Up Jawani', 'songs/inhoney/13 Get Up Jawani Ft. Shah (DjPunjab.Com).mp3', 18);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `uid` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(15) NOT NULL,
  `email_id` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `username`, `password`, `email_id`) VALUES
(1, 'Ankush Saini', 'ankush', 'ankushsaini88@gmail.com'),
(2, 'shikhar', 'shikhar', 'shikhar.bajaj16@gmail.com'),
(6, 'Arpit Atul', 'arpit', 'arpitpalarpwar@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `album_t`
--
ALTER TABLE `album_t`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `lang_t`
--
ALTER TABLE `lang_t`
  ADD PRIMARY KEY (`lid`);

--
-- Indexes for table `song_t`
--
ALTER TABLE `song_t`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `album_t`
--
ALTER TABLE `album_t`
  MODIFY `aid` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `lang_t`
--
ALTER TABLE `lang_t`
  MODIFY `lid` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `song_t`
--
ALTER TABLE `song_t`
  MODIFY `sid` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=68;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
