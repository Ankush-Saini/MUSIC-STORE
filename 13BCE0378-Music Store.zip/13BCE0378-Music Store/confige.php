<?php
	$servername="localhost";
	$username="root";
	$mysql_password="";
	$dbname="ms_db";
	
	//Create connection
	$conn=new mysqli($servername,$username,$mysql_password);
	mysql_select_db($dbname);
	//Check Connection
	if($conn->connect_error)
	{
		die("Connection Failed".$conn->connect_error);
	}	
	echo "Connection Succesful";
?>