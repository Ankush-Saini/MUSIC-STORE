<?php
//require 'core.php';
session_start();
//session_cache_expire();
//session_unset();
session_destroy();                      // can also write header('Location: index.php');
header('Location:login.php');     //takes back to index page tocheck
?>