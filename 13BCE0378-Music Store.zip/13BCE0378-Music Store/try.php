<?php
	include 'header.html';
	include 'try1.html';
	$x=5;
	for($i=0;$i<$x;$i++)
	{
		echo '<div class="album_info">';
		echo	'<img src="sun.jpg" width="128" height="140">
			<br />';
		echo	'<a href="#" class="imgdesc">Sun Sathiya</a>';
		echo '</div>';
	}	
?>