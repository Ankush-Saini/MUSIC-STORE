<?php
	session_start();
	include "header.html";
	include "try3.html";
?>
<?php
	//session_start();
?>
<?php
	include "connect.php";
	if(isset($_POST['name'])&&isset($_POST['password']))
	{	
		$uname=$_POST['name'];
		$pass=$_POST['password'];
		//echo $uname;
		//echo $pass;
		//$password_hash=md5($pass);       
		echo "<br/>";
		if(!empty($uname)&&!empty($pass))
		{
			$query="SELECT `uid` FROM `user` WHERE `username`='$uname' and `password`='$pass'";
			if($query_run=mysql_query($query))
			{
				$query_num_rows=mysql_num_rows($query_run);
				if($query_num_rows==0)
				{
					echo 'ERROR';
					echo '<div style="text-transform:capitalize;width:600px;height:45px;letter-spacing:1px;display:block;border:5px ridge black;background-color:#fdfdfd;box-shadow:0 0 5px black;border-radius:3px;">';
					echo '<p style="text-transform:uppercase;text-align:center;">Invalid Username/Password Combination</p></div>';
		
					//echo "Invalid Username/Password Combination";
				}	
				else if($query_num_rows==1)
				{
					echo 'Valid Username/Password';
					$user_id=mysql_result($query_run,0,'uid');
					 //echo $user_id;
					$_SESSION['user_id'] = $user_id;   //starting a session for respective user
				    //print_r($_SESSION);
					header('Location:index_loggedin.php');	
				}
			}
			else
			{
				echo "No";
			}	
		}	
		else
		{
			echo 'You must supply a username and password';
		}
	}
?>