<?php
	ob_start();
    session_start();
?>
<?php
	include 'header.html';
	include 'connect.php';
	$current_file=$_SERVER['SCRIPT_NAME'];
	if(isset($_SERVER['HTTP_REFERER'])&&!empty($_SERVER['HTTP_REFERER']))
	{$http_referer=$_SERVER['HTTP_REFERER'];}
	echo "<br/>";
	if(isset($_SESSION["lid"])&& !empty($_SESSION["lid"]))
	{
		//var_dump($_SESSION["lid"]);
		//echo $_SESSION["lid"];
		$k=$_SESSION["lid"];
		$qry="SELECT `aid`,`aname`,`apath` from `album_t` where `lid`='".$k."'";
		$query_run=mysql_query($qry);
		while($row=mysql_fetch_array($query_run))
		{
			$img=$row["apath"];
			if(empty($img))
			{
				$img="Album/download.png";
			}
			//echo $row["aname"];
			echo "<html><head>";
			echo '<link rel="stylesheet" type="text/css" href="css/album_info.css">';
			echo "<head>";
				echo '<div class="album_info">';
				echo	'<img src="'.$img.'" width="128" height="140"><br />';
				echo	'<a href="index_loggedin.php?aid='.$row["aid"].'" class="imgdesc">'.$row["aname"].'</a>';
			echo '</div>';
		}	
	}
	else
	{
		echo "No data Available";
	}
?>	