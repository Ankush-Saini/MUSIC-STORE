    <html>
    <head>
    <title></title>
  
	<link rel="stylesheet" type="text/css" href="main.css">
    </head>
    <body>
    <div id="header">
		<h1 style="font-family:myFirstFont;position:relative;left:60px;top:-26px;letter-spacing:1.5px;z-index:1;" id="site_name" onclick="myName();">Music Store</h1>
		<div id="nav">
			<ul>
				<li><a href="index.php" target="_self">Home</a></li>
				<li><a href="browse.php" target="_self">Browse</a></li>
				<li><a href="index_loggedin.php" target="_self">My Music</a></li>
				<li><a href="about.php" target="_self">About</a></li>
				<li><a href="contact.php" target="_self">Contact</a></li>
			</ul>
		</div>
    </div>
	<br><br><br><br><br><br>
	<div id="nav2">
		<ul>
			<li><a href="index.php?lang=hindi">Hindi</a></li>
			<li><a href="index.php?lang=english">English</a></li>
			<li><a href="index.php?lang=punjabi">Punjabi</a></li>
			<li><a href="index.php?lang=tamil">Tamil</a></li>
			<li><a href="#">Telugu</a></li>
			<li><a href="#">Marathi</a></li>
			<li><a href="#">Gujrati</a></li>
			<li><a href="#">Others</a></li>
		</ul>
	</div>
	<?php
		include 'connect.php';
		if (isset($_GET["lang"])) {
			echo $_GET["lang"];
			lang_click($_GET["lang"]);
		}
		/*else{
			echo "NOooooooooooooo";
			print_r($_GET);
		}*/
		function lang_click($k)
		{
			$qry="SELECT `alang` FROM `album_t`";
			$result=mysql_query($qry);
			if(mysql_result($result,0,'alang')===$k);
			{
				$lang=$k;
				$_SESSION["lang"]=$lang;
				header('Location:lang_select.php');
				echo $_SESSION["lang"];
			}
		}
	?>
    <div id="footer">
		<div id="player_controls">
			<!--<audio controls>
				<source src="1.ogg" type="audio/ogg">
				<source src="1.mp3" type="audio/mpeg">	
				Your browser does not support the audio element.
			</audio>-->
			<h3>&#169; Music Store</h3>
		</div>
	</div>
    </body>
    </html>