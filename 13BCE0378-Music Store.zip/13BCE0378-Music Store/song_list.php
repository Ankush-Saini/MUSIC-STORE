<?php
	ob_start();
    session_start();
?>
<?php
	include 'header_c.php';
	include 'connect.php';
	$current_file=$_SERVER['SCRIPT_NAME'];
	if(isset($_SERVER['HTTP_REFERER'])&&!empty($_SERVER['HTTP_REFERER']))
	{$http_referer=$_SERVER['HTTP_REFERER'];}
	if(isset($_SESSION["user_id"])&& !empty($_SESSION["user_id"]))
	{
		$k=$_SESSION['user_id'];
		$qry="SELECT `username` FROM `user` where `uid`=$k";
		if($query_run=mysql_query($qry))
		{
			$name=mysql_result($query_run,0,'username');
			echo '<span style="text-align:left;text-transform:capitalize;font-family:Comic Sans MS;color:#fdfdfd;position:fixed;top:90px;z-index:2;">Welcome '.$name;
			echo "</span>";
			echo '<a href="logout.php" style="text-transform:capitalize;font-family:Comic Sans MS;color:#fdfdfd;position:fixed;top:90px;right:7px;z-index:2;">Logout';
			echo '</a>';
			//echo $name;
		}	
	}
	else 
		echo "Nothing set";
	if(isset($_SESSION["album_id"])&& !empty($_SESSION["album_id"]))
	{
		//$k=1;
		//echo "itial".$k;
		$k=$_SESSION["album_id"];
		//echo "final".$k;
		$qry="SELECT `aname`,`apath` from `album_t` where aid=$k";
		$query_run=mysql_query($qry);
		while($row=mysql_fetch_assoc($query_run))
		{
			$img=$row["apath"];
			if(empty($img))
			{
				$img="Album/download4.png";
			}	
			echo '<div style="margin-left:250px;margin-top:20px;border:5px ridge black;border-radius:5px;width:800px;background-color:#fdfdfd;padding-bottom:0px;">';
			echo '<h1 style="position:relative;top:-22px;overflow:auto;">';
			echo '<img src="'.$img.'" width="180px" height="180px"/><span style="position:relative;left:150px;bottom:80px;">'.$row["aname"];
			echo "</span></h1>";
		}	
		//echo '<div style="margin-left:160px;">';
		echo '<table border="1" style="border-collapse:collapse;position:relative;top:-52px;margin-bottom:-35px;">';
		$sqry="SELECT `sname`,`spath` FROM `song_t` where aid=$k";
		$song_list=mysql_query($sqry);
		while($srow=mysql_fetch_assoc($song_list))
		{
			echo '<tr style="font-size:25px;"><td style="width:500px;padding-left:7px;">'.$srow["sname"];
			echo '</td>';
			echo '<td style="width:300px;padding-left:5px;padding-right:5px;">';
			echo '<audio controls>';
				//echo '<source src="'.$srow["spath"].'" type="audio/ogg">';
				echo '<source src="'.$srow["spath"].'" type="audio/mpeg">';
			echo "</audio>";
			echo "</td>";
			echo '</tr>';
		}	
		echo "</table>";
		echo '<input type="button" value="Go Back" onclick="GoBack();" style="background-color:#1a1a1a;color:white;font-size:16px;border-radius:5px;"/>';
		echo "</div>";
		echo "<br/><br/><br/>";
	}
	else 
		echo 'AF?afmkamfkma';
	//header('Location:index_loggedin.php');
	//session_unset();
?>	
<script type="text/javascript">
	function GoBack()
	{
		window.location="index_loggedin.php";
	}
</script>