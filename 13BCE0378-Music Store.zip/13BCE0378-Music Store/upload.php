<?php
	include 'header.html';
	include 'connect.php';
	echo '<form method="POST" action="upload.php">';
	echo '<select name="sname">';
	echo	'<option value="null" selected="selected">--Select the Option--</option>';
		echo  '<option name="sname" value="1"/>Album</option>';
		echo  '<option value="2" name="sname"/>Song</option>';
	echo	'</select>';
	echo '<input type="submit" value="Enter"/>';
	echo "</form>";
	if(isset($_POST['sname']))
	{
		if($_POST['sname']==1)
		{
			echo '<form method="POST" action="upload.php">';
			echo 'Album Name<input type="text" name="aname"/>';
			echo 'Album Path<input type="text" name="apath"/>';
			echo 'User_id<input type="text" name="uid"/>';
			echo '<input type="submit" value="Enter"/>';
			echo "</form>";
		}	
		else if ($_POST['sname']==2)
		{
			echo '<form method="POST" action="upload.php">';
			echo 'Song Name<input type="text" name="sname"/>';
			echo 'Song Path<input type="text" name="spath"/>';
			echo 'Album id<input type="text" name="aiid"/>';
			echo '<input type="submit" value="Enter"/>';
			echo "</form>";
		}	
	}	
	
	if(isset($_POST["aname"])&&isset($_POST["apath"])&&isset($_POST["uid"]))
	{
		$aname=$_POST["aname"];
		$apath=$_POST["apath"];
		$auid=$_POST["uid"];
		$qry="INSERT INTO `album_t` VALUES ('','$apath','$aname','','$auid')";
		$query_run=mysql_query($qry);
		echo "New Album Added Successfully";
		
	}
	else if(isset($_POST["sname"])&&isset($_POST["spath"])&&isset($_POST["aiid"]))
	{
		$sname=$_POST["sname"];
		$spath=$_POST["spath"];
		$aiid=$_POST["aiid"];
		echo $sname;
		echo $spath;
		echo $aiid;
		$qry="INSERT INTO `song_t` VALUES ('','$sname','$spath','$aiid')";
		$query_run=mysql_query($qry);
		echo "New Song Added Successfully";
	}	
	/*else
	{
		echo "Supply some album name/album path/user id";
	}*/	
?>