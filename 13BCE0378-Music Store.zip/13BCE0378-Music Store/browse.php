<?php
	include "header.html";
	include "connect.php";
	ob_start();
?>
<html>
<head>
	<style type="text/css">
		#BrowseElements a
		{
				color:black;
				text-decoration:none;
				word-spacing:1.4px;
				letter-spacing:0.5px;
		}
		#BrowseElements a:hover
		{
			text-shadow: 1px 1px 2px grey;
		}
	</style>
</head>
<body>
	<div id="BrowseElements" style="float:right;margin-right:70px;margin-top:50px;">
		<ul style="list-style:none;border:1px solid black;font-size:20px;width:200px;color:black;background-color:#fdfdfd;overflow:hidden;">
			<li><img src="Album/023713-black-inlay-steel-square-icon-culture-book3-open.png" width="160px;" height="auto"/></li>
			<li><a href="<?php echo 'browse.php?select=feature';?>">Featured Playlists</li>
			<li><a href="<?php echo 'browse.php?select=new';?>">New Releases</li>
			<li><a href="<?php echo 'browse.php?select=top15';?>">Weekly Top 15</li>
			<li><a href="<?php echo 'browse.php?select=all';?>">All Albums</li>
		</ul>
	</div>
	<?php
		echo "<br/>";
		if(!isset($_GET["select"]))
		{
			echo '<h2 style="position:absolute;top:200px;left:330px;color:black;font-size:40px;"> Music Store Browse';
			echo '</h2>';
			echo '<p style="position:absolute;top:300px;left:200px;color:black;font-size:32px;">';
			echo 'Get ready to browse through all the albums <br>available on music store';
			echo "</p>";
			echo '<img src="Album/img5.jpg" width="800px" style="margin-left:100px;margin-top:20px;box-shadow:0 0 5px black;"/>';
		}	
		if(isset($_GET["select"]))
		{
			//var_dump($_GET);
			$select=$_GET["select"];
			//echo $select;
			browse_click($select);
		}	
		function browse_click($select)
		{
			if($select=="all")
			{
				$qry="SELECT DISTINCT `aname`,`apath` from `album_t`";
			}
			else if($select=="new")
			{
				$qry="SELECT `aname`,`apath` from `album_t` where `releasetype`='new'";
			}	
			else if($select=="feature")
			{
				$qry="SELECT `aname`,`apath` from `album_t` where `releasetype`='featured'";
			}	
			/*else if($select=="top15")
			{
				$qry="SELECT `aname`,`apath` from `album_t`";	
			}*/
			else
			{
				$qry="SELECT `aname`,`apath` from `album_t`";
			}	
			$query_run=mysql_query($qry);
			while($row=mysql_fetch_array($query_run))
			{
				$img=$row["apath"];
				if(empty($img))
				{
					$img="Album/download.png";
				}
				echo "<html><head>";
				echo '<link rel="stylesheet" type="text/css" href="css/album_info.css">';
				echo "<head>";
				echo '<div class="album_info">';
				echo	'<img src="'.$img.'" width="128" height="140"><br />';
				echo	'<a href="browse.php?aname='.$row["aname"].'" class="imgdesc">'.$row["aname"].'</a>';
				echo '</div>';
			}	
		}
		 if (isset($_GET['aname'])) {
			album_click($_GET['aname']);
		}
		function album_click($k)
		{
			$qry="SELECT `aid` FROM `album_t` where `aname`='".$k."'";
			$result=mysql_query($qry);
			$result_num=mysql_num_rows($result);
			if($result_num!=0)
			{
				while($row=mysql_fetch_array($result))
				{	
					$album_id=$row["aid"];
					$_SESSION["album_id"]=$album_id;
					header('Location:song_list.php');
					echo $_SESSION["album_id"];
				}
			}
			else
				echo "Album not found";
		}
	/*	if(isset($_GET["aname"]) && !empty($_GET["aname"]))
		{
			$anam = $_GET["aname"];
			//echo $anam;
			$Qry="SELECT `aname` FROM `album_t`";
			$query=mysql_query($Qry);
			if(mysql_fetch_field($query,0)==$anam)
			{	
				$aname=$anam;
				album_click($aname);
				echo $aname;
			}	
		}*/
	?>
	<br/>
	<br/>
	<br/>
</body>
</html>	