<?php
	include 'connect.php';
	ob_start();
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Music Store</title>
	<meta charset="UTF-8">
	<link rel="icon" href="toolbar_music.ico">
	<link rel="stylesheet" type="text/css" href="main.css">
	<style type="text/css">
		body
		{
			background-image:url(back_hd.jpg);
			width:100%;
			background-attachment:fixed;
			background-size:cover;
		}
		section{
			position:absolute;
			top:110px;
			left:0px;
			width:100%;
			height:100%;
			border: 2px solid black;
			padding-left:5%;
			margin-bottom:50px;
		}
		#nav2
		{
			position:relative;
			left:-8px;
			z-index:1;
		}
		#player_controls
		{	
			background-color:#0d0d0d;/*Can also try black*/
			position:fixed;
			bottom:0px;
			left:0px;
			height:45px;
			width:100%;
			border:2px solid black;
		}
		#site_name
		{
			cursor:pointer;
			display:block;
		}

	#img_player
	{
		position:absolute;
		left:400px;
		top:8%;
		width:850px;
		height:315px;
		background-image:url('Carousel/1.jpg');
		background-attachment:no-repeat;
		-webkit-animation-name: music; /* Chrome, Safari, Opera */
		-webkit-animation-duration: 4s; /* Chrome, Safari, Opera */
		animation-name: music;
		animation-duration: 45s;
		animation-delay:3s;
		animation-iteration-count: infinite;
		animation-direction: alternate;
		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
	}
	@-webkit-keyframes music {
	0%   {background-image: url('Carousel/1.jpg');}
    20%  {background-image: url('Carousel/2.jpg');}
    40%  {background-image: url('Carousel/3.jpg');}
    60% {background-image: url('Carousel/4.jpg');}
	80%	{background-image: url('Carousel/5.jpg');}
	100% {background-image: url('Carousel/6.jpg');}
 	}

	/* Standard syntax */
	@keyframes music {
	0%   {background-image: url('Carousel/1.jpg');}
    20%  {background-image: url('Carousel/2.jpg');}
    40%  {background-image: url('Carousel/3.jpg');}
    60% {background-image: url('Carousel/4.jpg');}
	80%	{background-image: url('Carousel/5.jpg');}
	100% {background-image: url('Carousel/6.jpg');}
	}
	.jumbotron
	{
		position:relative;
		left:1%;
		top:5%;
		width:240px;
	}
	#cwhite
	{
		color:white;
	}
	#about
	{
		position:fixed;
		left:0px;
		text-align:center;
		margin-top:50px;
		width:100%;
	}
	.jumbotron h1{
		display: block;
		font-size: 2em;
		-webkit-margin-before: 0.67em;
		-webkit-margin-after: 0.67em;
		-webkit-margin-start: 0px;
		-webkit-margin-end: 0px;
		font-weight: bold;
	}
	#cwhite
	{
		color:white;
	}
	#about
	{
		position:relative;
		left:0px;
		text-align:center;
		margin-top:120px;
		width:100%;
		letter-spacing:1px;
	}
	#ms_ab
	{
		background-color:black;
		position:relative;
		top:550px;
		left:-8px;
		color:white;
		margin-bottom:50px;
		height:auto;
		letter-spacing:1px;
		word-spacing:2px;
		font-family:verdana;
		border-radius:2px;
		box-shadow:0 0 30px black;
	}
	#ms_ab tr
	{
		margin-bottom:40px;
	}
	</style>
	<script type="text/javascript">
		function myName()
		{
			var x = document.getElementById("site_name");
		
			if(x.style.color=="black")
			{
				x.style.color="white";
			}
			else
			{
				x.style.color="black";
			}
		}
	</script>
</head>
<body>	
	<div id="header">
		<h1 style="font-family:myFirstFont;position:relative;left:60px;top:-26px;letter-spacing:1.5px;" id="site_name" onclick="myName();">Music Store</h1>
		<!-- <marquee style="background-color:black;color:white;letter-spacing:1.5px;word-spacing:2.5px;">
			Welcome to the world of music!!!
		</marquee> -->
		<div id="nav">
			<ul>
				<li><a href="index.php" target="_self">Home</a></li>
				<li><a href="browse.php" target="_self">Browse</a></li>
				<li><a href="login.php" target="_self">My Music</a></li>
				<li><a href="about.php" target="_self">About</a></li>
				<li><a href="contact.php" target="_self">Contact</a></li>
			</ul>
		</div>
	</div>
	<div id="nav2">
		<ul>
			<li><a href="<?php echo 'index.php?lang=hindi';?>">Hindi</a></li>
			<li><a href="<?php echo 'index.php?lang=english';?>">English</a></li>
			<li><a href="index.php?lang=punjabi">Punjabi</a></li>
			<li><a href="index.php?lang=tamil">Tamil</a></li>
			<li><a href="#">Telugu</a></li>
			<li><a href="#">Marathi</a></li>
			<li><a href="#">Gujrati</a></li>
			<li><a href="#">Others</a></li>
		</ul>
	</div>
	<?php
		if (isset($_GET["lang"]) && !empty($_GET["lang"])) {
			//var_dump($_GET);
			$lang=$_GET["lang"];
			//echo $lang;
			lang_click($lang);
		}
		else{
			echo "NO Language Preference";
			//print_r($_GET);
		}
		function lang_click($k)
		{
			if($k=="hindi")
			{
				$lid=1;
			}	
			else if($k=="english")
			{
				$lid=2;
			}	
			else
			{
				$lid=3;
			}	
			echo $lid;
			$qry="SELECT DISTINCT `aname` FROM `album_t` where `lid`='".$lid."'";
			$result=mysql_query($qry);
			while(mysql_fetch_array($result))
			{
				$_SESSION["lid"]=$lid;
				header('Location:lang_select.php');
				//echo $_SESSION["lang"];
			}
		}
	?>
	<section class="section">
		<div class="jumbotron">
		<h1>What is Music?</h1>      
		<p>Music is a form of entertainment that puts sounds together in a way that people like or find interesting.</p>
		<br /><strong>Hannah Harrington, Saving June</strong>
		<q>He took his pain and turned it into something beautiful. Into something that people connect to. And that's what good music does. It speaks to you. It changes you. 
		</q>
		</div>
		<div id="img_player">
		</div>
		<div id="about">
			<p style="font-family:verdana;font-size:40px;"><span id="cwhite">Music Store :</span> The Largest Music Collection</p>
		</div>
	</section>	
	<div id="ms_ab">
		<div><h1 style="font-size:34px;border-top:1px ridge white;border-bottom:1px ridge white;width:300px;position:relative;left:530px;top:50px;text-align:center;">Our Features</h1></div>
		<table style="padding-right:100px;padding-top:40px;">
			<tr><td style="width:200px;padding-left:90px;"><img src="Album/music-icone-7536-128.png" width="128px" height="128px;"/></td>
				<td>
					<h4 style="color:#fdfdfd;">Music Store brings you the largest collection of Music that you can find on a single website. You can select songs from various albums present on the Music Store. </h4>	
				</td>
			</tr>
			<tr><td style="width:200px;padding-left:90px;"><img src="Album/profile.png" width="128px" height="128px;"/></td>
				<td>
					<h4 style="color:white;">Now enjoy music in your own language. You can select language in which you want to listen the song.</h4>	
				</td>
			</tr>
			<tr><td style="width:200px;padding-left:90px;"><img src="Album/search-icon-48834.png" width="128px" height="128px;"/></td>
				<td>
					<h4 style="color:white;">Search for a song and get the essence of song with great charm.</h4>	
				</td>
			</tr>
		</table>
	</div>
	
	<div id="player_controls">
		<!--<audio controls>
			<source src="1.ogg" type="audio/ogg">
			<source src="1.mp3" type="audio/mpeg">	
			Your browser does not support the audio element.
		</audio>-->
		<h3>&#169; Music Store</h3>
	</div>
</body>
</html>