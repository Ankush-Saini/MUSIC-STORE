<?php
	include "header.html";
	echo "<br/>";
	echo '<div style="position:absolute;left:520px;width:250px;">';
	echo '<h2 style="text-transform:uppercase;border-top:1px solid black;border-bottom:1px solid black;padding:5px; text-align:center;">About Us</h2>';
	echo '</div><br/><div style="display:block;position:relative;top:60px;left:120px;width:1100px;">
	<p style="float:left;font-size:18px;letter-spacing:1px;word-spacing:1.5px;text-indent:70px;">
	Music Store is a place where users can find a wide range of music collections and can able to choose among various music albums.
	Music Store is designed to provide a high level of user interaction with the music to the users.
	Music Store is a site where anyone who has a craze to listen music can visit to listen to music of his/her choice.';
	echo "<br><br>";
	echo "Music Store is an initiative of Mr.Ankush Saini, a student of VIT UNIVERSITY. He got the idea of music store while going through some similar websites.
	 So while pursuing his \"Internet and Web Programming\" course he started creating this website.</p>";
	echo "</div>";
?>