<?php
	include 'header.html';
	echo '<div style="font-size:20px;position:absolute;left:400px;text-transform:capitalize;letter-spacing:1px;display:block;border:5px ridge black;padding:15px;margin-top:50px;background-color:#fdfdfd;box-shadow:0 0 5px black;border-radius:3px;">';
	echo '<div><h2 style="text-transform:uppercase;border-top:1px solid black;border-bottom:1px solid black;padding:5px; text-align:center;">Contact Us</h2></div>';
	echo "<h3>For technical support,please contact:</h3>";
	echo "<h3>Ankush Saini<br>13BCE0378<br>9943848588
	<br>Project Head</h3></div>";
?>	