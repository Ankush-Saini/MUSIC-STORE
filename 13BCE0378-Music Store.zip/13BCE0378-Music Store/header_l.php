<a href="header_l.php?lang=hindi">Hindi</a>
<?php
	$lang = $_GET['lang'];
	echo $lang;
	ob_start();
	if(session_status()==PHP_SESSION_ACTIVE)
	{	
	include 'connect.php';
	$current_file=$_SERVER['SCRIPT_NAME'];
	if(isset($_SERVER['HTTP_REFERER'])&&!empty($_SERVER['HTTP_REFERER']))
	{$http_referer=$_SERVER['HTTP_REFERER'];}
	if(isset($_SESSION["user_id"])&& !empty($_SESSION["user_id"]))
	{
		$k=$_SESSION['user_id'];
		$qry="SELECT `username` FROM `user` where `uid`=$k";
		if($query_run=mysql_query($qry))
		{
			$name=mysql_result($query_run,0,'username');
			echo '<span style="text-align:left;text-transform:capitalize;font-family:Comic Sans MS;color:#fdfdfd;position:fixed;top:90px;z-index:2;">Welcome '.$name;
			echo "</span>";
			echo '<a href="logout.php" style="text-transform:capitalize;font-family:Comic Sans MS;color:#fdfdfd;position:fixed;top:90px;right:7px;z-index:2;">Logout';
			echo '</a>';
		}	
	}
	}
	else
		echo "NO SESSION";
?>