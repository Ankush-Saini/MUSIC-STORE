<?php
	include 'connect.php';
	include "header.html";
	include "try3.html";
	if(isset($_POST['rname'])&&isset($_POST['rpass']))
	{
		if(isset($_POST['rcpass']))
		{	
			if($_POST['rpass']==$_POST['rcpass'])
			{	
				$name=$_POST['rname'];
				$pass=$_POST['rpass'];
				$email=$_POST['email'];
				$qry="INSERT INTO `user` VALUES('','$name','$pass','$email')";
				$result=mysql_query($qry);
				header('Location:login.php');
			}
		}
		else
		{
			echo 'Please enter something in confirm password';
		}		
	}	
	else
	{
		echo "You must supply a username/password;";
	}
?>
<script type="text/javascript">
	myReg();
</script>